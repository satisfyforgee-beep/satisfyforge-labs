# SatisfyForge: Tile Panic

Original Roblox survival-game prototype. A neon 8x8 arena loses tiles each wave; last survivors win 50 in-game coins. Includes automatic round loop, HUD, lobby, leaderboard, and respawn handling.

## Install
1. Open a new Baseplate in Roblox Studio.
2. In Explorer, open ServerScriptService.
3. Add a Script, replace its contents with `ServerScriptService/Game.server.lua`.
4. Press Play to test, then publish from Studio when ready.

## Status
Prototype source is prepared but has **not** been tested in Roblox Studio or published to Roblox. Coins and wins are session-only and reset when the server closes. No monetization or paid assets. This is a foundation, not a complete commercially ready game.
